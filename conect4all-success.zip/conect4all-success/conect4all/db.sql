-- Active: 1667399794662@@127.0.0.1@3306@nodelogin

CREATE DATABASE IF NOT EXIST nodelogin;

USE nodelogin;

CREATE TABLE users (
    email VARCHAR(100) NOT NULL PRIMARY KEY,
    name VARCHAR(50) NOT NULL, 
    password VARCHAR(255) NOT NULL
);